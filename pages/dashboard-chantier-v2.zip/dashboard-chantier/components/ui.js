// Utilitaires partagés

export function fmtEuro(n) {
  return new Intl.NumberFormat('fr-FR', { style: 'currency', currency: 'EUR', maximumFractionDigits: 0 }).format(n || 0);
}

export function fmtDate(d) {
  if (!d) return '—';
  return new Date(d).toLocaleDateString('fr-FR');
}

export function isRetard(date_echeance, statut) {
  if (!date_echeance || statut === 'Terminé') return false;
  return new Date(date_echeance) < new Date();
}

export const STATUS_CONFIG = {
  'En cours':   { label: 'EN COURS',   bg: '#DBEAFE', color: '#1D4ED8', border: '#BFDBFE' },
  'En attente': { label: 'EN ATTENTE', bg: '#F1F5F9', color: '#475569', border: '#CBD5E1' },
  'Bloqué':     { label: 'BLOQUÉ',     bg: '#FEE2E2', color: '#B91C1C', border: '#FECACA' },
  'Terminé':    { label: 'TERMINÉ',    bg: '#DCFCE7', color: '#15803D', border: '#BBF7D0' },
  'À faire':    { label: 'À FAIRE',    bg: '#F1F5F9', color: '#475569', border: '#CBD5E1' },
};

export function StatusBadge({ statut, small }) {
  const cfg = STATUS_CONFIG[statut] || STATUS_CONFIG['En attente'];
  return (
    <span style={{
      fontSize: small ? 10 : 10, fontWeight: 700,
      padding: small ? '2px 6px' : '3px 8px',
      borderRadius: 20, textTransform: 'uppercase', letterSpacing: 0.5,
      whiteSpace: 'nowrap', flexShrink: 0,
      border: `1px solid ${cfg.border}`,
      background: cfg.bg, color: cfg.color
    }}>{cfg.label}</span>
  );
}

export function ProgressBar({ value, height = 6 }) {
  const color = value >= 80 ? '#22C55E' : value >= 40 ? '#0055FF' : '#F59E0B';
  return (
    <div style={{ height, background: 'var(--gray-200)', borderRadius: height / 2, overflow: 'hidden' }}>
      <div style={{ width: `${Math.min(100, value || 0)}%`, height: '100%', background: color, borderRadius: height / 2, transition: 'width 600ms ease' }} />
    </div>
  );
}

export const TYPE_TACHE_COLORS = {
  'Dépose':   { bg: '#FEF3C7', color: '#92400E', border: '#FDE68A' },
  'Pose':     { bg: '#DBEAFE', color: '#1D4ED8', border: '#BFDBFE' },
  'Finition': { bg: '#F0FDF4', color: '#15803D', border: '#BBF7D0' },
  'Contrôle': { bg: '#F5F3FF', color: '#6D28D9', border: '#DDD6FE' },
};

export function TypeBadge({ type }) {
  const cfg = TYPE_TACHE_COLORS[type] || { bg: '#F1F5F9', color: '#475569', border: '#CBD5E1' };
  return (
    <span style={{ fontSize: 10, fontWeight: 600, padding: '2px 7px', borderRadius: 4, border: `1px solid ${cfg.border}`, background: cfg.bg, color: cfg.color }}>
      {type}
    </span>
  );
}

export const inputStyle = {
  width: '100%', padding: '8px 12px', border: '1px solid var(--gray-300)',
  borderRadius: 6, fontSize: 13, outline: 'none', background: '#fff',
  color: 'var(--gray-900)', transition: 'border-color 150ms',
};

export const selectStyle = { ...inputStyle, cursor: 'pointer', appearance: 'none' };
export const labelStyle = { fontSize: 11, color: 'var(--gray-500)', textTransform: 'uppercase', letterSpacing: 0.5, marginBottom: 4, display: 'block', fontWeight: 500 };

export function Btn({ children, onClick, variant = 'primary', size = 'md', disabled, type = 'button', style: extraStyle }) {
  const base = { border: 'none', borderRadius: 6, fontFamily: 'inherit', fontWeight: 500, cursor: disabled ? 'not-allowed' : 'pointer', display: 'inline-flex', alignItems: 'center', gap: 6, transition: 'opacity 150ms', opacity: disabled ? 0.6 : 1 };
  const sizes = { sm: { fontSize: 12, padding: '5px 12px' }, md: { fontSize: 13, padding: '7px 16px' }, lg: { fontSize: 14, padding: '10px 20px' } };
  const variants = {
    primary: { background: 'var(--blue)', color: '#fff' },
    secondary: { background: 'var(--gray-100)', color: 'var(--gray-700)', border: '1px solid var(--gray-300)' },
    danger: { background: '#FEF2F2', color: 'var(--red)', border: '1px solid #FECACA' },
    ghost: { background: 'transparent', color: 'var(--gray-500)' },
  };
  return (
    <button type={type} onClick={onClick} disabled={disabled} style={{ ...base, ...sizes[size], ...variants[variant], ...extraStyle }}>
      {children}
    </button>
  );
}
