import Link from 'next/link';
import { useRouter } from 'next/router';

export default function Layout({ children, alertesCount = 0 }) {
  const router = useRouter();

  const navItems = [
    { href: '/dashboard', label: 'Chantiers' },
    { href: '/entreprises', label: 'Entreprises' },
    { href: '/relances', label: 'Relances', badge: alertesCount },
  ];

  return (
    <div style={{ minHeight: '100vh', background: 'var(--gray-50)' }}>
      <header style={{
        background: '#fff', borderBottom: '1px solid var(--gray-300)',
        padding: '0 24px', display: 'flex', alignItems: 'center',
        justifyContent: 'space-between', height: 56,
        position: 'sticky', top: 0, zIndex: 100,
        boxShadow: '0 1px 3px rgba(0,0,0,.05)'
      }}>
        <Link href="/dashboard" style={{ textDecoration: 'none', color: 'inherit', display: 'flex', alignItems: 'center', gap: 10 }}>
          <div style={{ width: 34, height: 34, background: 'var(--blue)', borderRadius: 7, display: 'flex', alignItems: 'center', justifyContent: 'center' }}>
            <svg width="18" height="18" viewBox="0 0 24 24" fill="white">
              <path d="M3 9l9-7 9 7v11a2 2 0 01-2 2H5a2 2 0 01-2-2z"/>
              <polyline points="9 22 9 12 15 12 15 22" fill="none" stroke="white" strokeWidth="2"/>
            </svg>
          </div>
          <div>
            <div style={{ fontFamily: "'Barlow Condensed',sans-serif", fontWeight: 700, fontSize: 16, letterSpacing: 0.5, lineHeight: 1 }}>SITE COMMANDER</div>
            <div style={{ fontSize: 10, color: 'var(--gray-500)', letterSpacing: 0.5, textTransform: 'uppercase', marginTop: 1 }}>APHP Paris</div>
          </div>
        </Link>

        <nav style={{ display: 'flex', gap: 4 }}>
          {navItems.map(item => {
            const active = router.pathname === item.href || (item.href !== '/dashboard' && router.pathname.startsWith(item.href));
            return (
              <Link key={item.href} href={item.href} style={{
                padding: '6px 16px', borderRadius: 7, textDecoration: 'none',
                fontSize: 13, fontWeight: 500, display: 'flex', alignItems: 'center', gap: 6,
                background: active ? 'var(--blue)' : 'transparent',
                color: active ? '#fff' : 'var(--gray-500)',
                transition: 'background 150ms, color 150ms',
              }}>
                {item.label}
                {item.badge > 0 && (
                  <span style={{ background: active ? 'rgba(255,255,255,.25)' : 'var(--red)', color: '#fff', fontSize: 10, fontWeight: 700, padding: '1px 6px', borderRadius: 10, minWidth: 18, textAlign: 'center' }}>
                    {item.badge}
                  </span>
                )}
              </Link>
            );
          })}
        </nav>
      </header>
      <main>{children}</main>
    </div>
  );
}
