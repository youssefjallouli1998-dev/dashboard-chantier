import { useState } from 'react';
import Link from 'next/link';
import Layout from '../components/Layout';
import { StatusBadge, ProgressBar, fmtEuro, inputStyle, selectStyle, labelStyle, Btn } from '../components/ui';
import { ENTREPRISES_SEED } from '../data/seed.js';

export async function getServerSideProps() {
  const base = process.env.NEXT_PUBLIC_BASE_URL || 'http://localhost:3000';
  const [chantiersRes, statsRes, alertesRes] = await Promise.all([
    fetch(`${base}/api/chantiers`).then(r => r.json()).catch(() => ({ chantiers: [] })),
    fetch(`${base}/api/stats`).then(r => r.json()).catch(() => ({})),
    fetch(`${base}/api/alertes`).then(r => r.json()).catch(() => ({ retards: [], bloques: [], chantiers_bloques: [] }))
  ]);
  return { props: { chantiers: chantiersRes.chantiers || [], stats: statsRes, alertes: alertesRes } };
}

const FORM_INIT = {
  nom: '', site: 'Hôpital Vaugirard', statut: 'En attente',
  budget_ht: '', budget_ttc: '', description: '',
  date_debut: '', date_fin_prevue: '',
  responsable: '',
  intervenants: [],
  zones: [{ nom: '' }, { nom: '' }],
};

function SectionTitle({ label }) {
  return (
    <div style={{ fontSize: 11, fontWeight: 600, color: 'var(--blue)', textTransform: 'uppercase', letterSpacing: 1, marginBottom: 12, display: 'flex', alignItems: 'center', gap: 8 }}>
      <div style={{ height: 1, background: 'var(--blue-light)', flex: 1 }} />
      {label}
      <div style={{ height: 1, background: 'var(--blue-light)', flex: 1 }} />
    </div>
  );
}

function NouveauChantierModal({ onClose, onCreated }) {
  const [form, setForm] = useState(FORM_INIT);
  const [saving, setSaving] = useState(false);
  const [errors, setErrors] = useState({});

  function setField(k, v) { setForm(f => ({ ...f, [k]: v })); }
  function setZone(i, v) { setForm(f => { const z = [...f.zones]; z[i] = { nom: v }; return { ...f, zones: z }; }); }
  function addZone() { setForm(f => ({ ...f, zones: [...f.zones, { nom: '' }] })); }
  function removeZone(i) { setForm(f => ({ ...f, zones: f.zones.filter((_, idx) => idx !== i) })); }

  function validate() {
    const e = {};
    if (!form.nom.trim()) e.nom = 'Le nom est obligatoire';
    setErrors(e);
    return Object.keys(e).length === 0;
  }

  async function handleSubmit(e) {
    e.preventDefault();
    if (!validate()) return;
    setSaving(true);
    const res = await fetch('/api/chantiers', {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify({ ...form, budget_ht: Number(form.budget_ht) || 0, budget_ttc: Number(form.budget_ttc) || 0, zones: form.zones.filter(z => z.nom.trim()) }),
    });
    const data = await res.json();
    setSaving(false);
    if (data.chantier) onCreated(data.chantier);
  }

  return (
    <div style={{ position: 'fixed', inset: 0, background: 'rgba(0,0,0,.45)', zIndex: 300, display: 'flex', alignItems: 'center', justifyContent: 'center', padding: 16 }} onClick={e => e.target === e.currentTarget && onClose()}>
      <div style={{ background: '#fff', borderRadius: 14, width: '100%', maxWidth: 620, maxHeight: '92vh', overflowY: 'auto', boxShadow: '0 20px 60px rgba(0,0,0,.2)' }}>
        <div style={{ padding: '20px 24px 16px', borderBottom: '1px solid var(--gray-100)', display: 'flex', alignItems: 'center', justifyContent: 'space-between', position: 'sticky', top: 0, background: '#fff', zIndex: 1 }}>
          <div>
            <h2 style={{ fontSize: 22, textTransform: 'uppercase' }}>Nouveau chantier</h2>
            <p style={{ fontSize: 12, color: 'var(--gray-500)', marginTop: 2 }}>Remplis la fiche avant de créer le chantier</p>
          </div>
          <button onClick={onClose} style={{ background: 'none', border: 'none', fontSize: 20, color: 'var(--gray-400)', cursor: 'pointer', padding: '4px 8px', borderRadius: 6 }}>✕</button>
        </div>

        <form onSubmit={handleSubmit} style={{ padding: 24 }}>
          {/* Informations générales */}
          <div style={{ marginBottom: 20 }}>
            <SectionTitle label="Informations générales" />
            <div style={{ marginBottom: 12 }}>
              <label style={labelStyle}>Nom du chantier *</label>
              <input style={{ ...inputStyle, borderColor: errors.nom ? 'var(--red)' : 'var(--gray-300)' }} placeholder="Ex : Rénovation vestiaires Bloc B" value={form.nom} onChange={e => setField('nom', e.target.value)} />
              {errors.nom && <div style={{ fontSize: 11, color: 'var(--red)', marginTop: 3 }}>{errors.nom}</div>}
            </div>
            <div style={{ display: 'grid', gridTemplateColumns: '1fr 1fr', gap: 12, marginBottom: 12 }}>
              <div>
                <label style={labelStyle}>Site *</label>
                <select style={selectStyle} value={form.site} onChange={e => setField('site', e.target.value)}>
                  <option>Hôpital Vaugirard</option>
                  <option>HEGP</option>
                </select>
              </div>
              <div>
                <label style={labelStyle}>Statut initial</label>
                <select style={selectStyle} value={form.statut} onChange={e => setField('statut', e.target.value)}>
                  {['En attente', 'En cours', 'Bloqué'].map(s => <option key={s}>{s}</option>)}
                </select>
              </div>
            </div>
            <div>
              <label style={labelStyle}>Description</label>
              <textarea style={{ ...inputStyle, minHeight: 70, resize: 'vertical' }} placeholder="Périmètre des travaux, contexte..." value={form.description} onChange={e => setField('description', e.target.value)} />
            </div>
          </div>

          {/* Budget */}
          <div style={{ marginBottom: 20 }}>
            <SectionTitle label="Budget" />
            <div style={{ display: 'grid', gridTemplateColumns: '1fr 1fr', gap: 12 }}>
              <div>
                <label style={labelStyle}>Montant HT (€)</label>
                <input type="number" style={inputStyle} placeholder="Ex : 75000" min="0" value={form.budget_ht} onChange={e => { setField('budget_ht', e.target.value); if (e.target.value && !form.budget_ttc) setField('budget_ttc', Math.round(Number(e.target.value) * 1.2)); }} />
              </div>
              <div>
                <label style={labelStyle}>Montant TTC (€)</label>
                <input type="number" style={inputStyle} placeholder="Calculé auto (HT × 1.2)" min="0" value={form.budget_ttc} onChange={e => setField('budget_ttc', e.target.value)} />
              </div>
            </div>
          </div>

          {/* Planning */}
          <div style={{ marginBottom: 20 }}>
            <SectionTitle label="Planning" />
            <div style={{ display: 'grid', gridTemplateColumns: '1fr 1fr', gap: 12 }}>
              <div>
                <label style={labelStyle}>Date de début</label>
                <input type="date" style={inputStyle} value={form.date_debut} onChange={e => setField('date_debut', e.target.value)} />
              </div>
              <div>
                <label style={labelStyle}>Date de fin prévue</label>
                <input type="date" style={inputStyle} value={form.date_fin_prevue} onChange={e => setField('date_fin_prevue', e.target.value)} />
              </div>
            </div>
          </div>

          {/* Responsable + Intervenants */}
          <div style={{ marginBottom: 20 }}>
            <SectionTitle label="Équipe & Intervenants" />
            <div style={{ marginBottom: 12 }}>
              <label style={labelStyle}>Responsable du chantier</label>
              <input style={inputStyle} placeholder="Ex : Youssef JALLOULI" value={form.responsable} onChange={e => setField('responsable', e.target.value)} />
            </div>
            <div>
              <label style={labelStyle}>Entreprises intervenantes</label>
              <p style={{ fontSize: 12, color: 'var(--gray-500)', marginBottom: 8 }}>Sélectionne les entreprises qui interviennent sur ce chantier</p>
              <div style={{ display: 'grid', gridTemplateColumns: 'repeat(3, 1fr)', gap: 6 }}>
                {ENTREPRISES_SEED.map(e => {
                  const selected = form.intervenants.includes(e.nom);
                  return (
                    <button key={e.id} type="button" onClick={() => {
                      setField('intervenants', selected
                        ? form.intervenants.filter(n => n !== e.nom)
                        : [...form.intervenants, e.nom]);
                    }} style={{
                      padding: '6px 10px', borderRadius: 6, fontSize: 12, cursor: 'pointer',
                      border: selected ? '2px solid var(--blue)' : '1px solid var(--gray-200)',
                      background: selected ? 'var(--blue-light)' : '#fff',
                      color: selected ? '#1D4ED8' : 'var(--gray-700)',
                      fontWeight: selected ? 600 : 400, textAlign: 'left',
                      transition: 'all 150ms',
                    }}>
                      {selected && '✓ '}{e.nom}
                      <div style={{ fontSize: 10, color: selected ? '#3B82F6' : 'var(--gray-400)', marginTop: 1 }}>{e.lots[0]}</div>
                    </button>
                  );
                })}
              </div>
              {form.intervenants.length > 0 && (
                <div style={{ marginTop: 8, fontSize: 12, color: 'var(--gray-500)' }}>
                  {form.intervenants.length} entreprise{form.intervenants.length > 1 ? 's' : ''} sélectionnée{form.intervenants.length > 1 ? 's' : ''}
                </div>
              )}
            </div>
          </div>

          {/* Zones */}
          <div style={{ marginBottom: 24 }}>
            <SectionTitle label="Zones du chantier" />
            <p style={{ fontSize: 12, color: 'var(--gray-500)', marginBottom: 10 }}>Découpe le chantier en zones (ex : Vestiaires hommes, Sanitaires, Couloir...)</p>
            <div style={{ display: 'flex', flexDirection: 'column', gap: 8 }}>
              {form.zones.map((z, i) => (
                <div key={i} style={{ display: 'flex', gap: 8, alignItems: 'center' }}>
                  <span style={{ fontSize: 12, color: 'var(--gray-400)', minWidth: 20, textAlign: 'right' }}>{i + 1}.</span>
                  <input style={{ ...inputStyle, flex: 1 }} placeholder={`Zone ${i + 1}`} value={z.nom} onChange={e => setZone(i, e.target.value)} />
                  {form.zones.length > 1 && (
                    <button type="button" onClick={() => removeZone(i)} style={{ background: 'none', border: 'none', color: 'var(--gray-300)', cursor: 'pointer', fontSize: 16, padding: '4px 6px', lineHeight: 1 }}
                      onMouseEnter={e => e.currentTarget.style.color = 'var(--red)'}
                      onMouseLeave={e => e.currentTarget.style.color = 'var(--gray-300)'}>✕</button>
                  )}
                </div>
              ))}
            </div>
            <button type="button" onClick={addZone} style={{ marginTop: 8, background: 'none', border: '1px dashed var(--gray-300)', borderRadius: 6, color: 'var(--gray-500)', fontSize: 12, padding: '6px 14px', cursor: 'pointer', width: '100%', transition: 'border-color 150ms, color 150ms' }}
              onMouseEnter={e => { e.currentTarget.style.borderColor = 'var(--blue)'; e.currentTarget.style.color = 'var(--blue)'; }}
              onMouseLeave={e => { e.currentTarget.style.borderColor = 'var(--gray-300)'; e.currentTarget.style.color = 'var(--gray-500)'; }}>
              + Ajouter une zone
            </button>
          </div>

          <div style={{ display: 'flex', gap: 10, justifyContent: 'flex-end', paddingTop: 16, borderTop: '1px solid var(--gray-100)' }}>
            <Btn variant="secondary" onClick={onClose} type="button">Annuler</Btn>
            <Btn type="submit" disabled={saving} style={{ minWidth: 150, justifyContent: 'center' }}>
              {saving ? 'Création...' : 'Créer le chantier'}
            </Btn>
          </div>
        </form>
      </div>
    </div>
  );
}

function ChantierCard({ chantier, onDelete }) {
  const avancement = chantier.zones?.length
    ? Math.round(chantier.zones.reduce((s, z) => s + z.avancement, 0) / chantier.zones.length)
    : 0;

  async function handleDelete(e) {
    e.preventDefault();
    e.stopPropagation();
    if (!confirm(`Supprimer "${chantier.nom}" ? Cette action supprimera aussi toutes les tâches et devis associés.`)) return;
    await fetch(`/api/chantiers/${chantier.id}`, { method: 'DELETE' });
    onDelete(chantier.id);
  }

  return (
    <div style={{ position: 'relative' }} className="chantier-card-wrap">
      <button onClick={handleDelete} title="Supprimer ce chantier" className="delete-btn" style={{
        position: 'absolute', top: 10, right: 10, zIndex: 2,
        width: 26, height: 26, borderRadius: '50%',
        background: '#fff', border: '1px solid var(--gray-200)',
        color: 'var(--gray-300)', cursor: 'pointer', fontSize: 12,
        display: 'flex', alignItems: 'center', justifyContent: 'center',
        opacity: 0, transition: 'opacity 200ms, color 150ms, border-color 150ms, background 150ms',
      }}
      onMouseEnter={e => { e.currentTarget.style.color = 'var(--red)'; e.currentTarget.style.borderColor = '#FECACA'; e.currentTarget.style.background = '#FFF5F5'; }}
      onMouseLeave={e => { e.currentTarget.style.color = 'var(--gray-300)'; e.currentTarget.style.borderColor = 'var(--gray-200)'; e.currentTarget.style.background = '#fff'; }}>
        ✕
      </button>
      <style>{`.chantier-card-wrap:hover .delete-btn { opacity: 1 !important; }`}</style>

      <Link href={`/chantier/${chantier.id}`} style={{ textDecoration: 'none', color: 'inherit' }}>
        <div style={{
          background: '#fff', border: `1px solid ${chantier.statut === 'Bloqué' ? '#FECACA' : 'var(--gray-300)'}`,
          borderRadius: 10, padding: 18, cursor: 'pointer', height: '100%', display: 'flex', flexDirection: 'column',
          transition: 'transform 200ms, border-color 200ms, box-shadow 200ms',
        }}
        onMouseEnter={e => { e.currentTarget.style.transform = 'translateY(-2px)'; e.currentTarget.style.borderColor = 'var(--blue)'; e.currentTarget.style.boxShadow = '0 4px 12px rgba(0,85,255,.1)'; }}
        onMouseLeave={e => { e.currentTarget.style.transform = 'none'; e.currentTarget.style.borderColor = chantier.statut === 'Bloqué' ? '#FECACA' : 'var(--gray-300)'; e.currentTarget.style.boxShadow = 'none'; }}
        >
          <div style={{ display: 'flex', alignItems: 'flex-start', justifyContent: 'space-between', marginBottom: 6, gap: 8, paddingRight: 20 }}>
            <h3 style={{ fontSize: 17, lineHeight: 1.2, flex: 1 }}>{chantier.nom}</h3>
            <StatusBadge statut={chantier.statut} />
          </div>
          <div style={{ display: 'flex', alignItems: 'center', gap: 4, fontSize: 12, color: 'var(--gray-500)', marginBottom: 12 }}>
            <svg width="12" height="12" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2"><path d="M21 10c0 7-9 13-9 13s-9-6-9-13a9 9 0 0118 0z"/><circle cx="12" cy="10" r="3"/></svg>
            {chantier.site}
          </div>
          <div style={{ display: 'flex', justifyContent: 'space-between', fontSize: 12, color: 'var(--gray-500)', marginBottom: 5 }}>
            <span>Avancement global</span>
            <span style={{ fontWeight: 600, color: 'var(--gray-900)' }}>{avancement}%</span>
          </div>
          <ProgressBar value={avancement} />
          <div style={{ marginBottom: 14 }} />
          <div style={{ display: 'flex', flexWrap: 'wrap', gap: 5, marginBottom: 12, flex: 1 }}>
            {chantier.zones?.length > 0
              ? chantier.zones.slice(0, 3).map(z => <span key={z.nom} style={{ fontSize: 11, background: 'var(--gray-100)', color: 'var(--gray-500)', padding: '2px 8px', borderRadius: 4 }}>{z.nom}</span>)
              : <span style={{ fontSize: 11, color: 'var(--gray-400)', fontStyle: 'italic' }}>Aucune zone définie</span>
            }
            {chantier.zones?.length > 3 && <span style={{ fontSize: 11, color: 'var(--gray-400)' }}>+{chantier.zones.length - 3}</span>}
          </div>
          <div style={{ display: 'flex', alignItems: 'center', justifyContent: 'space-between', borderTop: '1px solid var(--gray-100)', paddingTop: 12, marginTop: 'auto' }}>
            <div>
              <div style={{ fontSize: 11, color: 'var(--gray-500)' }}>Budget TTC</div>
              <div style={{ fontFamily: "'Barlow Condensed',sans-serif", fontWeight: 700, fontSize: 16 }}>{fmtEuro(chantier.budget_ttc)}</div>
            </div>
            <span style={{ fontSize: 12, color: 'var(--blue)', fontWeight: 500 }}>Voir détails ›</span>
          </div>
        </div>
      </Link>
    </div>
  );
}

function StatCard({ icon, value, label, bg }) {
  return (
    <div style={{ background: '#fff', border: '1px solid var(--gray-200)', borderRadius: 10, padding: '16px 20px', display: 'flex', alignItems: 'center', gap: 14 }}>
      <div style={{ width: 40, height: 40, borderRadius: 8, background: bg, display: 'flex', alignItems: 'center', justifyContent: 'center', flexShrink: 0 }}>{icon}</div>
      <div>
        <div style={{ fontFamily: "'Barlow Condensed',sans-serif", fontWeight: 700, fontSize: 26, lineHeight: 1 }}>{value}</div>
        <div style={{ fontSize: 11, color: 'var(--gray-500)', textTransform: 'uppercase', letterSpacing: 0.5, marginTop: 2 }}>{label}</div>
      </div>
    </div>
  );
}

export default function Dashboard({ chantiers: initial, stats: initialStats, alertes }) {
  const [chantiers, setChantiers] = useState(initial);
  const [filterSite, setFilterSite] = useState('');
  const [filterStatut, setFilterStatut] = useState('');
  const [showModal, setShowModal] = useState(false);

  const filtered = chantiers.filter(c => {
    if (filterSite && c.site !== filterSite) return false;
    if (filterStatut && c.statut !== filterStatut) return false;
    return true;
  });

  const sites = [...new Set(chantiers.map(c => c.site))];
  const nbAlertes = (alertes?.retards?.length || 0) + (alertes?.bloques?.length || 0);
  const enCours = chantiers.filter(c => c.statut === 'En cours').length;
  const budgetTotal = chantiers.reduce((s, c) => s + (c.budget_ttc || 0), 0);

  function handleCreated(c) { setChantiers(cs => [...cs, c]); setShowModal(false); }
  function handleDelete(id) { setChantiers(cs => cs.filter(c => c.id !== id)); }

  const selectBase = { padding: '7px 32px 7px 12px', border: '1px solid var(--gray-300)', borderRadius: 6, fontSize: 13, color: 'var(--gray-900)', background: '#fff', cursor: 'pointer', appearance: 'none', backgroundImage: "url(\"data:image/svg+xml,%3Csvg xmlns='http://www.w3.org/2000/svg' width='12' height='12' fill='%2364748B' viewBox='0 0 16 16'%3E%3Cpath d='M7.247 11.14L2.451 5.658C1.885 5.013 2.345 4 3.204 4h9.592a1 1 0 0 1 .753 1.659l-4.796 5.48a1 1 0 0 1-1.506 0z'/%3E%3C/svg%3E\")", backgroundRepeat: 'no-repeat', backgroundPosition: 'right 10px center' };

  return (
    <Layout alertesCount={nbAlertes}>
      <div style={{ padding: 24, maxWidth: 1280, margin: '0 auto' }}>
        {/* Titre + bouton + */}
        <div style={{ display: 'flex', alignItems: 'flex-end', justifyContent: 'space-between', marginBottom: 20 }}>
          <div>
            <h1 style={{ fontSize: 32, textTransform: 'uppercase', marginBottom: 4 }}>Mes Chantiers</h1>
            <p style={{ fontSize: 13, color: 'var(--gray-500)' }}>{chantiers.length} chantiers · {enCours} en cours</p>
          </div>
          <button onClick={() => setShowModal(true)} style={{
            display: 'flex', alignItems: 'center', gap: 8,
            background: 'var(--blue)', color: '#fff', border: 'none', borderRadius: 8,
            padding: '9px 20px', fontSize: 13, fontWeight: 600, cursor: 'pointer',
            fontFamily: 'inherit', boxShadow: '0 2px 8px rgba(0,85,255,.25)',
          }}
          onMouseEnter={e => e.currentTarget.style.background = 'var(--blue-hover)'}
          onMouseLeave={e => e.currentTarget.style.background = 'var(--blue)'}>
            <span style={{ fontSize: 20, fontWeight: 300, lineHeight: 1 }}>+</span>
            Nouveau chantier
          </button>
        </div>

        {/* Stats */}
        <div style={{ display: 'grid', gridTemplateColumns: 'repeat(4,1fr)', gap: 12, marginBottom: 16 }}>
          <StatCard icon={<svg width="20" height="20" viewBox="0 0 24 24" fill="none" stroke="#3B82F6" strokeWidth="2"><rect x="3" y="3" width="18" height="18" rx="2"/><path d="M3 9h18M9 21V9"/></svg>} bg="#EFF6FF" value={chantiers.length} label={`Chantiers · ${enCours} en cours`} />
          <StatCard icon={<svg width="20" height="20" viewBox="0 0 24 24" fill="none" stroke="#22C55E" strokeWidth="2"><line x1="12" y1="1" x2="12" y2="23"/><path d="M17 5H9.5a3.5 3.5 0 000 7h5a3.5 3.5 0 010 7H6"/></svg>} bg="#F0FDF4" value={budgetTotal ? Math.round(budgetTotal / 1000) + 'k€' : '—'} label="Budget total TTC" />
          <StatCard icon={<svg width="20" height="20" viewBox="0 0 24 24" fill="none" stroke="#F59E0B" strokeWidth="2"><path d="M10.29 3.86L1.82 18a2 2 0 001.71 3h16.94a2 2 0 001.71-3L13.71 3.86a2 2 0 00-3.42 0z"/><line x1="12" y1="9" x2="12" y2="13"/><line x1="12" y1="17" x2="12.01" y2="17"/></svg>} bg="#FFF7ED" value={nbAlertes} label="Alertes à traiter" />
          <StatCard icon={<svg width="20" height="20" viewBox="0 0 24 24" fill="none" stroke="#A855F7" strokeWidth="2"><polyline points="9 11 12 14 22 4"/><path d="M21 12v7a2 2 0 01-2 2H5a2 2 0 01-2-2V5a2 2 0 012-2h11"/></svg>} bg="#FDF4FF" value={initialStats?.nb_taches || 0} label={`Tâches · ${initialStats?.nb_terminees || 0} terminées`} />
        </div>

        {nbAlertes > 0 && (
          <Link href="/relances" style={{ textDecoration: 'none' }}>
            <div style={{ background: 'var(--red-light)', border: '1px solid #FECACA', borderRadius: 8, padding: '12px 16px', display: 'flex', alignItems: 'center', gap: 10, marginBottom: 16, cursor: 'pointer' }}>
              <span style={{ color: 'var(--red)', fontSize: 18 }}>⚠</span>
              <div>
                <div style={{ fontWeight: 600, color: '#B91C1C', fontSize: 13 }}>{nbAlertes} actions en retard — {alertes?.retards?.length || 0} tâches · {alertes?.chantiers_bloques?.length || 0} chantier(s) bloqué(s)</div>
                <div style={{ fontSize: 12, color: '#DC2626', marginTop: 1 }}>Cliquer pour voir les relances →</div>
              </div>
            </div>
          </Link>
        )}

        {/* Filtres */}
        <div style={{ display: 'flex', gap: 10, marginBottom: 20 }}>
          <select style={selectBase} value={filterSite} onChange={e => setFilterSite(e.target.value)}>
            <option value="">Tous les sites</option>
            {sites.map(s => <option key={s}>{s}</option>)}
          </select>
          <select style={selectBase} value={filterStatut} onChange={e => setFilterStatut(e.target.value)}>
            <option value="">Tous les statuts</option>
            {['En cours', 'En attente', 'Bloqué', 'Terminé'].map(s => <option key={s}>{s}</option>)}
          </select>
        </div>

        {/* Grille */}
        <div style={{ display: 'grid', gridTemplateColumns: 'repeat(3,1fr)', gap: 16 }}>
          {filtered.map(c => <ChantierCard key={c.id} chantier={c} onDelete={handleDelete} />)}

          {/* Carte "+ Nouveau" en fin de grille */}
          <div onClick={() => setShowModal(true)} style={{
            border: '2px dashed var(--gray-200)', borderRadius: 10, padding: 18,
            cursor: 'pointer', display: 'flex', flexDirection: 'column', alignItems: 'center',
            justifyContent: 'center', gap: 10, minHeight: 200, color: 'var(--gray-400)',
            transition: 'border-color 200ms, color 200ms, background 200ms',
          }}
          onMouseEnter={e => { e.currentTarget.style.borderColor = 'var(--blue)'; e.currentTarget.style.color = 'var(--blue)'; e.currentTarget.style.background = '#F5F8FF'; }}
          onMouseLeave={e => { e.currentTarget.style.borderColor = 'var(--gray-200)'; e.currentTarget.style.color = 'var(--gray-400)'; e.currentTarget.style.background = 'transparent'; }}>
            <div style={{ width: 44, height: 44, borderRadius: '50%', border: '2px dashed currentColor', display: 'flex', alignItems: 'center', justifyContent: 'center', fontSize: 24, fontWeight: 200, lineHeight: 1 }}>+</div>
            <div style={{ textAlign: 'center' }}>
              <div style={{ fontSize: 14, fontWeight: 600 }}>Nouveau chantier</div>
              <div style={{ fontSize: 12, marginTop: 2, opacity: 0.7 }}>Cliquer pour créer</div>
            </div>
          </div>

          {filtered.length === 0 && chantiers.length > 0 && (
            <div style={{ gridColumn: '1/-1', textAlign: 'center', padding: 60, color: 'var(--gray-400)' }}>Aucun chantier ne correspond aux filtres.</div>
          )}
        </div>
      </div>

      {showModal && <NouveauChantierModal onClose={() => setShowModal(false)} onCreated={handleCreated} />}
    </Layout>
  );
}
