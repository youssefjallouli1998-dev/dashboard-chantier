import { useState } from 'react';
import Layout from '../components/Layout';
import { TypeBadge, StatusBadge, fmtDate, Btn } from '../components/ui';

export async function getServerSideProps() {
  const base = process.env.NEXT_PUBLIC_BASE_URL || 'http://localhost:3000';
  const data = await fetch(`${base}/api/alertes`).then(r => r.json()).catch(() => ({ retards: [], bloques: [], chantiers_bloques: [] }));
  return { props: data };
}

export default function Relances({ retards = [], bloques = [], chantiers_bloques = [] }) {
  const [selected, setSelected] = useState([]);
  const [texte, setTexte] = useState('');
  const [generating, setGenerating] = useState(false);
  const [copied, setCopied] = useState(false);

  const allItems = [
    ...retards.map(t => ({ ...t, alerteType: 'retard' })),
    ...bloques.map(t => ({ ...t, alerteType: 'bloque' }))
  ];

  function toggleSelect(id) {
    setSelected(sel => sel.includes(id) ? sel.filter(s => s !== id) : [...sel, id]);
  }
  function selectAll() { setSelected(allItems.map(t => t.id)); }
  function deselectAll() { setSelected([]); }

  async function generer() {
    if (!selected.length) return;
    setGenerating(true);
    const res = await fetch('/api/relances/generer', {
      method: 'POST', headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify({ tache_ids: selected })
    });
    const data = await res.json();
    setTexte(data.texte || '');
    setGenerating(false);
  }

  async function copier() {
    await navigator.clipboard.writeText(texte);
    setCopied(true);
    setTimeout(() => setCopied(false), 2000);
  }

  const statCard = (icon, val, label, color) => (
    <div style={{ background: '#fff', border: '1px solid var(--gray-200)', borderRadius: 10, padding: '16px 20px', display: 'flex', alignItems: 'center', gap: 12 }}>
      <span style={{ fontSize: 20 }}>{icon}</span>
      <div>
        <div style={{ fontFamily: "'Barlow Condensed',sans-serif", fontWeight: 700, fontSize: 24, color }}>{val}</div>
        <div style={{ fontSize: 11, color: 'var(--gray-500)', textTransform: 'uppercase', letterSpacing: 0.5 }}>{label}</div>
      </div>
    </div>
  );

  return (
    <Layout alertesCount={retards.length + bloques.length}>
      <div style={{ padding: 24, maxWidth: 1200, margin: '0 auto' }}>
        <div style={{ display: 'flex', alignItems: 'center', justifyContent: 'space-between', marginBottom: 4 }}>
          <h1 style={{ fontSize: 32, textTransform: 'uppercase' }}>Relances</h1>
          <Btn variant="secondary" onClick={() => window.location.reload()}>↻ Actualiser</Btn>
        </div>
        <p style={{ fontSize: 13, color: 'var(--gray-500)', marginBottom: 20 }}>{retards.length + bloques.length} actions à traiter</p>

        <div style={{ display: 'grid', gridTemplateColumns: 'repeat(3,1fr)', gap: 12, marginBottom: 24 }}>
          {statCard('🔴', retards.length, 'Tâches en retard', 'var(--red)')}
          {statCard('🟡', bloques.length, 'Tâches bloquées', 'var(--amber)')}
          {statCard('🔴', chantiers_bloques.length, 'Chantiers bloqués', 'var(--red)')}
        </div>

        <div style={{ display: 'grid', gridTemplateColumns: '1fr 1fr', gap: 20 }}>
          {/* Colonne gauche */}
          <div>
            <div style={{ display: 'flex', alignItems: 'center', justifyContent: 'space-between', marginBottom: 12 }}>
              <h2 style={{ fontSize: 16 }}>Actions à relancer</h2>
              <div style={{ display: 'flex', gap: 8 }}>
                <button onClick={selectAll} style={{ background: 'none', border: 'none', fontSize: 12, color: 'var(--blue)', cursor: 'pointer', fontWeight: 500 }}>Tout sélectionner</button>
                <button onClick={deselectAll} style={{ background: 'none', border: 'none', fontSize: 12, color: 'var(--gray-500)', cursor: 'pointer' }}>Désélectionner</button>
              </div>
            </div>

            <div style={{ display: 'flex', flexDirection: 'column', gap: 8 }}>
              {allItems.map(t => (
                <div key={t.id} onClick={() => toggleSelect(t.id)} style={{
                  background: '#fff', border: `1px solid ${selected.includes(t.id) ? 'var(--blue)' : 'var(--gray-200)'}`,
                  borderRadius: 8, padding: '12px 14px', cursor: 'pointer', display: 'flex', alignItems: 'flex-start', gap: 10,
                  background: selected.includes(t.id) ? '#EFF6FF' : '#fff', transition: 'background 150ms, border-color 150ms'
                }}>
                  <div style={{ width: 16, height: 16, borderRadius: 4, border: `2px solid ${selected.includes(t.id) ? 'var(--blue)' : 'var(--gray-300)'}`, background: selected.includes(t.id) ? 'var(--blue)' : '#fff', flexShrink: 0, marginTop: 2, display: 'flex', alignItems: 'center', justifyContent: 'center' }}>
                    {selected.includes(t.id) && <span style={{ color: '#fff', fontSize: 10, lineHeight: 1 }}>✓</span>}
                  </div>
                  <div style={{ flex: 1 }}>
                    <div style={{ display: 'flex', gap: 6, marginBottom: 4, flexWrap: 'wrap' }}>
                      <TypeBadge type={t.type_tache} />
                      <StatusBadge statut={t.statut} small />
                      {t.alerteType === 'retard' && <span style={{ fontSize: 10, fontWeight: 700, padding: '2px 6px', borderRadius: 4, background: '#FEF2F2', color: 'var(--red)', border: '1px solid #FECACA' }}>EN RETARD</span>}
                    </div>
                    <div style={{ fontSize: 13, fontWeight: 500, marginBottom: 2 }}>{t.description}</div>
                    <div style={{ fontSize: 11, color: 'var(--gray-500)' }}>
                      {t.chantier_nom} · {t.zone} · <strong>{t.entreprise_nom}</strong>
                      {t.date_echeance && <span style={{ color: 'var(--red)', marginLeft: 6 }}>Éch. {fmtDate(t.date_echeance)}</span>}
                    </div>
                  </div>
                </div>
              ))}
              {allItems.length === 0 && <div style={{ textAlign: 'center', padding: 40, color: 'var(--gray-400)' }}>Aucune tâche en retard ou bloquée.</div>}
            </div>

            {chantiers_bloques.length > 0 && (
              <div style={{ marginTop: 20 }}>
                <h3 style={{ fontSize: 13, fontWeight: 600, color: 'var(--gray-500)', textTransform: 'uppercase', letterSpacing: 0.5, marginBottom: 8 }}>Chantiers bloqués</h3>
                {chantiers_bloques.map(c => (
                  <div key={c.id} style={{ background: '#FFF5F5', border: '1px solid #FECACA', borderRadius: 8, padding: '10px 14px', marginBottom: 6, display: 'flex', justifyContent: 'space-between', alignItems: 'center' }}>
                    <span style={{ fontWeight: 500, fontSize: 13 }}>{c.nom}</span>
                    <span style={{ fontSize: 11, color: 'var(--gray-500)' }}>{c.site}</span>
                  </div>
                ))}
              </div>
            )}
          </div>

          {/* Colonne droite */}
          <div>
            <div style={{ background: '#fff', border: '1px solid var(--gray-200)', borderRadius: 10, padding: 20, position: 'sticky', top: 72 }}>
              <h2 style={{ fontSize: 16, marginBottom: 12 }}>Générer une relance</h2>
              <div style={{ fontSize: 13, color: 'var(--gray-500)', marginBottom: 14 }}>
                {selected.length} tâche(s) sélectionnée(s)
              </div>
              <Btn onClick={generer} disabled={!selected.length || generating} style={{ width: '100%', justifyContent: 'center', marginBottom: 12 }}>
                {generating ? 'Génération...' : 'Générer le texte'}
              </Btn>

              {texte && (
                <>
                  <textarea value={texte} readOnly style={{ width: '100%', minHeight: 280, padding: 12, border: '1px solid var(--gray-200)', borderRadius: 6, fontSize: 12, fontFamily: 'monospace', resize: 'vertical', lineHeight: 1.5, color: 'var(--gray-700)', background: 'var(--gray-50)' }} />
                  <Btn variant="secondary" onClick={copier} style={{ width: '100%', justifyContent: 'center', marginTop: 8 }}>
                    {copied ? '✓ Copié !' : 'Copier le texte'}
                  </Btn>
                </>
              )}
            </div>
          </div>
        </div>
      </div>
    </Layout>
  );
}
