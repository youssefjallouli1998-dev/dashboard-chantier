import { useState } from 'react';
import Layout from '../components/Layout';
import { fmtEuro } from '../components/ui';

export async function getServerSideProps() {
  const base = process.env.NEXT_PUBLIC_BASE_URL || 'http://localhost:3000';
  const data = await fetch(`${base}/api/entreprises`).then(r => r.json()).catch(() => ({ entreprises: [] }));
  return { props: { entreprises: data.entreprises || [] } };
}

export default function Entreprises({ entreprises }) {
  const [expanded, setExpanded] = useState(null);

  function toggle(id) { setExpanded(expanded === id ? null : id); }

  const total_ht = entreprises.reduce((s, e) => s + (e.devis_total_ttc || 0), 0);

  return (
    <Layout>
      <div style={{ padding: 24, maxWidth: 1000, margin: '0 auto' }}>
        <h1 style={{ fontSize: 32, textTransform: 'uppercase', marginBottom: 4 }}>Entreprises</h1>
        <p style={{ fontSize: 13, color: 'var(--gray-500)', marginBottom: 20 }}>
          {entreprises.length} entreprises référencées · {fmtEuro(total_ht)} engagé TTC
        </p>

        <div style={{ display: 'flex', flexDirection: 'column', gap: 8 }}>
          {entreprises.map(e => {
            const isOpen = expanded === e.id;
            const hasRetard = e.nb_retards > 0;
            const hasBloque = e.nb_bloques > 0;

            return (
              <div key={e.id} style={{ background: '#fff', border: '1px solid var(--gray-200)', borderRadius: 10, overflow: 'hidden' }}>
                {/* Ligne fermée */}
                <div onClick={() => toggle(e.id)} style={{ padding: '14px 18px', display: 'flex', alignItems: 'center', gap: 14, cursor: 'pointer' }}
                  onMouseEnter={e => e.currentTarget.style.background = 'var(--gray-50)'}
                  onMouseLeave={e => e.currentTarget.style.background = '#fff'}
                >
                  <div style={{ width: 38, height: 38, borderRadius: 8, background: 'var(--blue-light)', display: 'flex', alignItems: 'center', justifyContent: 'center', fontFamily: "'Barlow Condensed',sans-serif", fontWeight: 700, fontSize: 13, color: '#1D4ED8', flexShrink: 0 }}>
                    {e.nom.slice(0, 2)}
                  </div>
                  <div style={{ flex: 1 }}>
                    <div style={{ fontWeight: 600, fontSize: 14 }}>{e.nom}</div>
                    <div style={{ fontSize: 12, color: 'var(--gray-500)' }}>{e.lots?.join(' · ')} · {e.nb_taches} tâche(s) · {e.chantiers_actifs?.length || 0} chantier(s)</div>
                  </div>
                  <div style={{ display: 'flex', gap: 6 }}>
                    {hasRetard && <span style={{ fontSize: 10, fontWeight: 700, padding: '2px 8px', borderRadius: 20, background: '#FEE2E2', color: '#B91C1C', border: '1px solid #FECACA' }}>{e.nb_retards} retard</span>}
                    {hasBloque && <span style={{ fontSize: 10, fontWeight: 700, padding: '2px 8px', borderRadius: 20, background: '#FEF3C7', color: '#92400E', border: '1px solid #FDE68A' }}>{e.nb_bloques} bloqué</span>}
                    {!hasRetard && !hasBloque && <span style={{ fontSize: 10, fontWeight: 700, padding: '2px 8px', borderRadius: 20, background: '#DCFCE7', color: '#15803D', border: '1px solid #BBF7D0' }}>OK</span>}
                  </div>
                  <span style={{ color: 'var(--gray-400)', fontSize: 14, transition: 'transform 200ms', transform: isOpen ? 'rotate(180deg)' : 'none' }}>▾</span>
                </div>

                {/* Ligne ouverte */}
                {isOpen && (
                  <div style={{ borderTop: '1px solid var(--gray-100)', padding: '16px 18px', background: 'var(--gray-50)' }}>
                    <div style={{ display: 'grid', gridTemplateColumns: '1fr 1fr', gap: 16, marginBottom: 16 }}>
                      <div>
                        <div style={{ fontSize: 11, color: 'var(--gray-500)', textTransform: 'uppercase', letterSpacing: 0.5, marginBottom: 8 }}>Contact</div>
                        <div style={{ fontSize: 13, fontWeight: 500 }}>{e.contact || '—'}</div>
                        <div style={{ fontSize: 12, color: 'var(--gray-500)', marginTop: 2 }}>{e.telephone || ''}</div>
                        <div style={{ fontSize: 12, color: 'var(--blue)', marginTop: 2 }}>
                          {e.email && <a href={`mailto:${e.email}`} style={{ color: 'var(--blue)', textDecoration: 'none' }}>{e.email}</a>}
                        </div>
                      </div>
                      <div>
                        <div style={{ fontSize: 11, color: 'var(--gray-500)', textTransform: 'uppercase', letterSpacing: 0.5, marginBottom: 8 }}>Stats</div>
                        <div style={{ display: 'grid', gridTemplateColumns: '1fr 1fr', gap: 8 }}>
                          {[['Terminées', e.nb_terminees, '#22C55E'], ['En cours', e.nb_en_cours, 'var(--blue)'], ['En retard', e.nb_retards, 'var(--red)'], ['Devis TTC', fmtEuro(e.devis_total_ttc), 'var(--gray-900)']].map(([label, val, color]) => (
                            <div key={label}>
                              <div style={{ fontSize: 11, color: 'var(--gray-400)' }}>{label}</div>
                              <div style={{ fontSize: 16, fontFamily: "'Barlow Condensed',sans-serif", fontWeight: 700, color }}>{val}</div>
                            </div>
                          ))}
                        </div>
                      </div>
                    </div>

                    {e.chantiers_actifs?.length > 0 && (
                      <div style={{ marginBottom: 12 }}>
                        <div style={{ fontSize: 11, color: 'var(--gray-500)', textTransform: 'uppercase', letterSpacing: 0.5, marginBottom: 6 }}>Chantiers actifs</div>
                        <div style={{ display: 'flex', flexWrap: 'wrap', gap: 6 }}>
                          {e.chantiers_actifs.map(c => <span key={c} style={{ fontSize: 12, background: 'var(--blue-light)', color: '#1D4ED8', padding: '3px 10px', borderRadius: 20 }}>{c}</span>)}
                        </div>
                      </div>
                    )}

                    {e.historique_devis?.length > 0 && (
                      <div>
                        <div style={{ fontSize: 11, color: 'var(--gray-500)', textTransform: 'uppercase', letterSpacing: 0.5, marginBottom: 6 }}>Historique devis</div>
                        {e.historique_devis.map(d => (
                          <div key={d.id} style={{ display: 'flex', justifyContent: 'space-between', fontSize: 12, padding: '4px 0', borderBottom: '1px solid var(--gray-200)' }}>
                            <span style={{ color: 'var(--gray-700)' }}>{d.description}</span>
                            <span style={{ fontWeight: 600 }}>{fmtEuro(d.montant_ttc)}</span>
                          </div>
                        ))}
                      </div>
                    )}
                  </div>
                )}
              </div>
            );
          })}
        </div>
      </div>
    </Layout>
  );
}
