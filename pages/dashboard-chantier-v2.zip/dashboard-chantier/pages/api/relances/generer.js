import { genererRelance } from '../../../lib/db.js';
export default function handler(req, res) {
  if (req.method !== 'POST') return res.status(405).end();
  const { tache_ids } = req.body;
  if (!tache_ids?.length) return res.status(400).json({ error: 'tache_ids requis' });
  return res.status(200).json({ texte: genererRelance(tache_ids) });
}
