import { getDevis, createDevis } from '../../lib/db.js';

export default function handler(req, res) {
  if (req.method === 'GET') {
    const { chantier_id } = req.query;
    return res.status(200).json({ devis: getDevis(chantier_id) });
  }
  if (req.method === 'POST') {
    return res.status(201).json({ devis: createDevis(req.body) });
  }
  return res.status(405).end();
}
