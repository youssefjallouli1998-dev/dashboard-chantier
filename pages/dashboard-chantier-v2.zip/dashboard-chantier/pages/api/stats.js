import { getStats } from '../../lib/db.js';
export default (req, res) => res.status(200).json(getStats());
