import { getTaches, createTache, updateTacheStatut, deleteTache, reorderTaches, updateTacheDuree } from '../../lib/db.js';

export default function handler(req, res) {
  if (req.method === 'GET') {
    const { chantier_id } = req.query;
    const taches = getTaches(chantier_id);
    // Trier par ordre
    return res.status(200).json({ taches: taches.sort((a, b) => (a.ordre || 0) - (b.ordre || 0)) });
  }

  if (req.method === 'POST') {
    const tache = createTache(req.body);
    return res.status(201).json({ tache });
  }

  if (req.method === 'PUT') {
    const { id, statut, duree_jours, reorder, chantier_id, zone, ordered_ids } = req.body;
    
    if (reorder) {
      const taches = reorderTaches(chantier_id, zone, ordered_ids);
      return res.status(200).json({ taches });
    }
    if (duree_jours !== undefined) {
      const updated = updateTacheDuree(id, duree_jours);
      if (!updated) return res.status(404).json({ error: 'Tâche introuvable' });
      return res.status(200).json({ tache: updated });
    }
    const updated = updateTacheStatut(id, statut);
    if (!updated) return res.status(404).json({ error: 'Tâche introuvable' });
    return res.status(200).json({ tache: updated });
  }

  if (req.method === 'DELETE') {
    const { id } = req.query;
    const ok = deleteTache(id);
    if (!ok) return res.status(404).json({ error: 'Tâche introuvable' });
    return res.status(200).json({ success: true });
  }

  return res.status(405).end();
}
