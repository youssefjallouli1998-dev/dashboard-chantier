import { getChantier, updateChantierStatut, getTaches, getDevis, deleteChantier } from '../../../lib/db.js';

export default function handler(req, res) {
  const { id } = req.query;

  if (req.method === 'GET') {
    const chantier = getChantier(id);
    if (!chantier) return res.status(404).json({ error: 'Chantier introuvable' });
    return res.status(200).json({ chantier, taches: getTaches(id), devis: getDevis(id) });
  }

  if (req.method === 'PUT') {
    const { statut } = req.body;
    const updated = updateChantierStatut(id, statut);
    if (!updated) return res.status(404).json({ error: 'Chantier introuvable' });
    return res.status(200).json({ chantier: updated });
  }

  if (req.method === 'DELETE') {
    const ok = deleteChantier(id);
    if (!ok) return res.status(404).json({ error: 'Chantier introuvable' });
    return res.status(200).json({ success: true });
  }

  return res.status(405).end();
}
