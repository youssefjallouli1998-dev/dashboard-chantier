import { useState, useRef } from 'react';
import { useRouter } from 'next/router';
import Layout from '../../components/Layout';
import { StatusBadge, ProgressBar, TypeBadge, fmtEuro, fmtDate, isRetard, Btn, inputStyle, selectStyle, labelStyle, STATUS_CONFIG } from '../../components/ui';
import { ENTREPRISES_SEED } from '../../data/seed.js';

export async function getServerSideProps({ params }) {
  const base = process.env.NEXT_PUBLIC_BASE_URL || 'http://localhost:3000';
  const data = await fetch(`${base}/api/chantiers/${params.id}`).then(r => r.json()).catch(() => null);
  if (!data?.chantier) return { notFound: true };
  return { props: data };
}

// ─── Calcul durée planning ────────────────────────────────────────────────────
function addJoursOuvres(dateStr, jours) {
  if (!dateStr) return null;
  const d = new Date(dateStr);
  let added = 0;
  while (added < jours) {
    d.setDate(d.getDate() + 1);
    const day = d.getDay();
    if (day !== 0 && day !== 6) added++;
  }
  return d.toISOString().split('T')[0];
}

// ─── Composant ligne tâche draggable ─────────────────────────────────────────
function TacheLine({ tache, index, dateDebutChantier, onStatut, onDelete, onDuree, onDragStart, onDragOver, onDrop, dateDebut }) {
  const [editDuree, setEditDuree] = useState(false);
  const [dureeVal, setDureeVal] = useState(tache.duree_jours || 1);
  const dateFin = dateDebut ? addJoursOuvres(dateDebut, (tache.duree_jours || 1) - 1) : null;
  const retard = isRetard(tache.date_echeance, tache.statut);

  return (
    <div
      draggable
      onDragStart={e => onDragStart(e, index)}
      onDragOver={e => onDragOver(e, index)}
      onDrop={e => onDrop(e, index)}
      style={{
        background: '#fff',
        border: `1px solid ${retard ? '#FECACA' : 'var(--gray-200)'}`,
        borderRadius: 8, padding: '10px 14px',
        display: 'flex', alignItems: 'center', gap: 10,
        cursor: 'grab', transition: 'box-shadow 150ms',
        background: retard ? '#FFF5F5' : '#fff',
      }}
      onMouseEnter={e => e.currentTarget.style.boxShadow = '0 2px 8px rgba(0,0,0,.08)'}
      onMouseLeave={e => e.currentTarget.style.boxShadow = 'none'}
    >
      {/* Handle drag */}
      <div style={{ color: 'var(--gray-300)', cursor: 'grab', fontSize: 14, flexShrink: 0, userSelect: 'none' }} title="Glisser pour réordonner">⠿</div>

      {/* Numéro ordre */}
      <div style={{ width: 22, height: 22, borderRadius: '50%', background: 'var(--gray-100)', color: 'var(--gray-500)', fontSize: 11, fontWeight: 600, display: 'flex', alignItems: 'center', justifyContent: 'center', flexShrink: 0 }}>
        {tache.ordre || index + 1}
      </div>

      <TypeBadge type={tache.type_tache} />

      <div style={{ flex: 1, minWidth: 0 }}>
        <div style={{ fontWeight: 500, fontSize: 13, marginBottom: 1, whiteSpace: 'nowrap', overflow: 'hidden', textOverflow: 'ellipsis' }}>{tache.description}</div>
        <div style={{ fontSize: 11, color: 'var(--gray-500)', display: 'flex', gap: 8, flexWrap: 'wrap' }}>
          {tache.entreprise_nom && <span style={{ fontWeight: 500 }}>{tache.entreprise_nom}</span>}
          {dateDebut && <span style={{ color: 'var(--blue)' }}>Début {fmtDate(dateDebut)} → Fin {fmtDate(dateFin)}</span>}
          {tache.date_echeance && retard && <span style={{ color: 'var(--red)', fontWeight: 600 }}>⚠ EN RETARD (éch. {fmtDate(tache.date_echeance)})</span>}
        </div>
      </div>

      {/* Durée */}
      <div style={{ flexShrink: 0, display: 'flex', alignItems: 'center', gap: 4 }}>
        {editDuree ? (
          <input
            type="number" min="1" max="365"
            value={dureeVal}
            onChange={e => setDureeVal(e.target.value)}
            onBlur={() => { onDuree(tache.id, Number(dureeVal)); setEditDuree(false); }}
            onKeyDown={e => { if (e.key === 'Enter') { onDuree(tache.id, Number(dureeVal)); setEditDuree(false); } if (e.key === 'Escape') setEditDuree(false); }}
            autoFocus
            style={{ ...inputStyle, width: 60, padding: '4px 8px', textAlign: 'center' }}
          />
        ) : (
          <button onClick={() => setEditDuree(true)} title="Modifier la durée" style={{
            background: 'var(--gray-100)', border: '1px solid var(--gray-200)', borderRadius: 6,
            padding: '3px 10px', fontSize: 12, color: 'var(--gray-700)', cursor: 'pointer',
            display: 'flex', alignItems: 'center', gap: 4, whiteSpace: 'nowrap',
          }}>
            <svg width="11" height="11" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2"><circle cx="12" cy="12" r="10"/><polyline points="12 6 12 12 16 14"/></svg>
            {tache.duree_jours || 1}j
          </button>
        )}
      </div>

      {/* Statut */}
      <select value={tache.statut} onChange={e => onStatut(tache.id, e.target.value)} style={{ ...selectStyle, width: 'auto', fontSize: 11, padding: '4px 24px 4px 8px', flexShrink: 0 }}>
        {['À faire', 'En cours', 'Bloqué', 'Terminé'].map(s => <option key={s}>{s}</option>)}
      </select>

      <button onClick={() => onDelete(tache.id)} style={{ background: 'none', border: 'none', color: 'var(--gray-300)', cursor: 'pointer', padding: '2px 4px', fontSize: 14, flexShrink: 0, lineHeight: 1 }}
        onMouseEnter={e => e.currentTarget.style.color = 'var(--red)'}
        onMouseLeave={e => e.currentTarget.style.color = 'var(--gray-300)'}>✕</button>
    </div>
  );
}

// ─── Vue planning (Gantt simplifié) ──────────────────────────────────────────
function VuePlanning({ taches, dateDebutChantier }) {
  if (!dateDebutChantier) {
    return <div style={{ textAlign: 'center', padding: 40, color: 'var(--gray-400)' }}>Définissez une date de début de chantier pour voir le planning.</div>;
  }

  // Calculer les dates de début/fin de chaque tâche en séquence par zone
  const zones = [...new Set(taches.map(t => t.zone))];
  let rows = [];
  
  zones.forEach(zone => {
    const tachesZone = [...taches.filter(t => t.zone === zone)].sort((a, b) => (a.ordre || 0) - (b.ordre || 0));
    let currentDate = dateDebutChantier;
    tachesZone.forEach(t => {
      const debut = currentDate;
      const fin = addJoursOuvres(debut, (t.duree_jours || 1) - 1);
      rows.push({ ...t, zone, debut, fin });
      currentDate = addJoursOuvres(fin, 1);
    });
  });

  if (!rows.length) return <div style={{ textAlign: 'center', padding: 40, color: 'var(--gray-400)' }}>Aucune tâche planifiée.</div>;

  const minDate = new Date(dateDebutChantier);
  const maxDate = new Date(Math.max(...rows.map(r => new Date(r.fin))));
  const totalDays = Math.ceil((maxDate - minDate) / (1000 * 60 * 60 * 24)) + 1;
  const BAR_WIDTH = 800;

  function pct(dateStr) { return Math.round(((new Date(dateStr) - minDate) / (maxDate - minDate)) * 100); }
  function width(debut, fin) { return Math.max(2, Math.round(((new Date(fin) - new Date(debut)) / (maxDate - minDate)) * 100)); }

  const statusColors = { 'Terminé': '#22C55E', 'En cours': '#0055FF', 'Bloqué': '#EF4444', 'À faire': '#94A3B8' };

  return (
    <div style={{ overflowX: 'auto' }}>
      <div style={{ minWidth: 700 }}>
        {/* En-tête dates */}
        <div style={{ display: 'flex', marginBottom: 8, paddingLeft: 200 }}>
          <div style={{ position: 'relative', height: 20, flex: 1 }}>
            {[0, 25, 50, 75, 100].map(p => (
              <div key={p} style={{ position: 'absolute', left: `${p}%`, fontSize: 10, color: 'var(--gray-400)', transform: 'translateX(-50%)' }}>
                {new Date(minDate.getTime() + (maxDate - minDate) * p / 100).toLocaleDateString('fr-FR', { day: '2-digit', month: '2-digit' })}
              </div>
            ))}
          </div>
        </div>

        {rows.map((r, i) => (
          <div key={r.id} style={{ display: 'flex', alignItems: 'center', marginBottom: 6, gap: 8 }}>
            <div style={{ width: 190, flexShrink: 0 }}>
              <div style={{ fontSize: 12, fontWeight: 500, overflow: 'hidden', textOverflow: 'ellipsis', whiteSpace: 'nowrap' }} title={r.description}>{r.description}</div>
              <div style={{ fontSize: 10, color: 'var(--gray-400)' }}>{r.zone} · {r.duree_jours || 1}j</div>
            </div>
            <div style={{ flex: 1, position: 'relative', height: 28, background: 'var(--gray-100)', borderRadius: 4 }}>
              <div style={{
                position: 'absolute',
                left: `${pct(r.debut)}%`,
                width: `${width(r.debut, r.fin)}%`,
                height: '100%',
                background: statusColors[r.statut] || '#94A3B8',
                borderRadius: 4, opacity: 0.85,
                display: 'flex', alignItems: 'center', justifyContent: 'center',
              }}>
                <span style={{ fontSize: 10, color: '#fff', fontWeight: 500, padding: '0 4px', overflow: 'hidden', textOverflow: 'ellipsis', whiteSpace: 'nowrap' }}>
                  {r.duree_jours > 1 ? `${r.duree_jours}j` : ''}
                </span>
              </div>
            </div>
          </div>
        ))}

        <div style={{ display: 'flex', gap: 12, marginTop: 12, paddingLeft: 200, flexWrap: 'wrap' }}>
          {Object.entries(statusColors).map(([s, c]) => (
            <span key={s} style={{ display: 'flex', alignItems: 'center', gap: 4, fontSize: 11, color: 'var(--gray-500)' }}>
              <span style={{ width: 10, height: 10, borderRadius: 2, background: c, display: 'inline-block' }} />{s}
            </span>
          ))}
        </div>
      </div>
    </div>
  );
}

// ─── Page principale ──────────────────────────────────────────────────────────
export default function ChantierDetail({ chantier: initialChantier, taches: initialTaches, devis }) {
  const router = useRouter();
  const [chantier, setChantier] = useState(initialChantier);
  const [taches, setTaches] = useState([...(initialTaches || [])].sort((a, b) => (a.ordre || 0) - (b.ordre || 0)));
  const [tab, setTab] = useState('zones');
  const [showModal, setShowModal] = useState(false);
  const [form, setForm] = useState({ zone: '', type_tache: 'Pose', description: '', entreprise_id: '', entreprise_nom: '', date_echeance: '', duree_jours: 1 });
  const [saving, setSaving] = useState(false);
  const dragIdx = useRef(null);

  const avancement = chantier.zones?.length
    ? Math.round(chantier.zones.reduce((s, z) => s + z.avancement, 0) / chantier.zones.length) : 0;

  async function handleStatutChange(statut) {
    await fetch(`/api/chantiers/${chantier.id}`, { method: 'PUT', headers: { 'Content-Type': 'application/json' }, body: JSON.stringify({ statut }) });
    setChantier(c => ({ ...c, statut }));
  }

  async function handleTacheStatut(id, statut) {
    await fetch('/api/taches', { method: 'PUT', headers: { 'Content-Type': 'application/json' }, body: JSON.stringify({ id, statut }) });
    setTaches(ts => ts.map(t => t.id === id ? { ...t, statut } : t));
  }

  async function handleDeleteTache(id) {
    if (!confirm('Supprimer cette tâche ?')) return;
    await fetch(`/api/taches?id=${id}`, { method: 'DELETE' });
    setTaches(ts => ts.filter(t => t.id !== id));
  }

  async function handleDuree(id, duree_jours) {
    await fetch('/api/taches', { method: 'PUT', headers: { 'Content-Type': 'application/json' }, body: JSON.stringify({ id, duree_jours }) });
    setTaches(ts => ts.map(t => t.id === id ? { ...t, duree_jours } : t));
  }

  // Drag & drop reorder
  function handleDragStart(e, idx) {
    dragIdx.current = idx;
    e.dataTransfer.effectAllowed = 'move';
  }

  function handleDragOver(e, idx) {
    e.preventDefault();
    e.dataTransfer.dropEffect = 'move';
  }

  async function handleDrop(e, dropIdx) {
    e.preventDefault();
    if (dragIdx.current === null || dragIdx.current === dropIdx) return;
    const newTaches = [...taches];
    const [removed] = newTaches.splice(dragIdx.current, 1);
    newTaches.splice(dropIdx, 0, removed);
    const updated = newTaches.map((t, i) => ({ ...t, ordre: i + 1 }));
    setTaches(updated);
    dragIdx.current = null;
    // Sauvegarder le nouvel ordre
    const zone = removed.zone;
    const zoneIds = updated.filter(t => t.zone === zone).map(t => t.id);
    await fetch('/api/taches', { method: 'PUT', headers: { 'Content-Type': 'application/json' }, body: JSON.stringify({ reorder: true, chantier_id: chantier.id, zone, ordered_ids: updated.map(t => t.id) }) });
  }

  async function handleAddTache(e) {
    e.preventDefault();
    setSaving(true);
    const nextOrdre = taches.filter(t => t.zone === form.zone).length + 1;
    const res = await fetch('/api/taches', { method: 'POST', headers: { 'Content-Type': 'application/json' }, body: JSON.stringify({ ...form, chantier_id: chantier.id, ordre: nextOrdre }) });
    const data = await res.json();
    setTaches(ts => [...ts, data.tache].sort((a, b) => (a.ordre || 0) - (b.ordre || 0)));
    setShowModal(false);
    setForm({ zone: '', type_tache: 'Pose', description: '', entreprise_id: '', entreprise_nom: '', date_echeance: '', duree_jours: 1 });
    setSaving(false);
  }

  const zones = chantier.zones || [];
  const tachesParZone = zones.map(z => ({ ...z, taches: taches.filter(t => t.zone === z.nom).sort((a, b) => (a.ordre || 0) - (b.ordre || 0)) }));

  const statStyle = { background: '#fff', border: '1px solid var(--gray-200)', borderRadius: 10, padding: '16px 20px' };
  const tabs = [['zones', 'Zones'], ['taches', `Tâches (${taches.length})`], ['planning', 'Planning'], ['devis', `Devis (${devis?.length || 0})`]];

  return (
    <Layout>
      <div style={{ padding: 24, maxWidth: 1100, margin: '0 auto' }}>
        {/* Header */}
        <div style={{ display: 'flex', alignItems: 'center', gap: 12, marginBottom: 4 }}>
          <button onClick={() => router.push('/dashboard')} style={{ background: 'none', border: 'none', color: 'var(--gray-500)', fontSize: 20, cursor: 'pointer', padding: '4px 8px', borderRadius: 6 }}>←</button>
          <h1 style={{ fontSize: 28, textTransform: 'uppercase', flex: 1 }}>{chantier.nom}</h1>
          <select value={chantier.statut} onChange={e => handleStatutChange(e.target.value)} style={{ ...selectStyle, width: 'auto', padding: '6px 32px 6px 12px' }}>
            {['En attente', 'En cours', 'Bloqué', 'Terminé'].map(s => <option key={s}>{s}</option>)}
          </select>
        </div>
        <div style={{ display: 'flex', alignItems: 'center', gap: 12, marginBottom: 20, paddingLeft: 44, flexWrap: 'wrap' }}>
          <div style={{ display: 'flex', alignItems: 'center', gap: 4, fontSize: 13, color: 'var(--gray-500)' }}>
            <svg width="13" height="13" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2"><path d="M21 10c0 7-9 13-9 13s-9-6-9-13a9 9 0 0118 0z"/><circle cx="12" cy="10" r="3"/></svg>
            {chantier.site}
          </div>
          <StatusBadge statut={chantier.statut} />
          {chantier.responsable && <span style={{ fontSize: 12, color: 'var(--gray-500)' }}>👤 {chantier.responsable}</span>}
          {/* Intervenants */}
          {chantier.intervenants?.length > 0 && (
            <div style={{ display: 'flex', gap: 4, flexWrap: 'wrap' }}>
              {chantier.intervenants.map(nom => (
                <span key={nom} style={{ fontSize: 11, background: 'var(--blue-light)', color: '#1D4ED8', padding: '2px 8px', borderRadius: 12, fontWeight: 500 }}>{nom}</span>
              ))}
            </div>
          )}
        </div>

        {/* KPIs */}
        <div style={{ display: 'grid', gridTemplateColumns: 'repeat(4,1fr)', gap: 12, marginBottom: 24 }}>
          <div style={statStyle}>
            <div style={{ fontSize: 11, color: 'var(--gray-500)', textTransform: 'uppercase', letterSpacing: 0.5, marginBottom: 6 }}>Avancement</div>
            <div style={{ fontFamily: "'Barlow Condensed',sans-serif", fontWeight: 700, fontSize: 28, marginBottom: 4 }}>{avancement}%</div>
            <ProgressBar value={avancement} height={4} />
          </div>
          <div style={statStyle}>
            <div style={{ fontSize: 11, color: 'var(--gray-500)', textTransform: 'uppercase', letterSpacing: 0.5, marginBottom: 6 }}>Budget TTC</div>
            <div style={{ fontFamily: "'Barlow Condensed',sans-serif", fontWeight: 700, fontSize: 22 }}>{fmtEuro(chantier.budget_ttc)}</div>
            <div style={{ fontSize: 11, color: 'var(--gray-400)', marginTop: 2 }}>{fmtEuro(chantier.budget_ht)} HT</div>
          </div>
          <div style={statStyle}>
            <div style={{ fontSize: 11, color: 'var(--gray-500)', textTransform: 'uppercase', letterSpacing: 0.5, marginBottom: 6 }}>Fin prévue</div>
            <div style={{ fontFamily: "'Barlow Condensed',sans-serif", fontWeight: 700, fontSize: 18 }}>{fmtDate(chantier.date_fin_prevue)}</div>
            {chantier.date_debut && <div style={{ fontSize: 11, color: 'var(--gray-400)', marginTop: 2 }}>Début {fmtDate(chantier.date_debut)}</div>}
          </div>
          <div style={statStyle}>
            <div style={{ fontSize: 11, color: 'var(--gray-500)', textTransform: 'uppercase', letterSpacing: 0.5, marginBottom: 6 }}>Tâches</div>
            <div style={{ fontFamily: "'Barlow Condensed',sans-serif", fontWeight: 700, fontSize: 28 }}>{taches.length}</div>
            <div style={{ fontSize: 11, color: 'var(--gray-400)', marginTop: 2 }}>{taches.filter(t => t.statut === 'Terminé').length} terminées</div>
          </div>
        </div>

        {/* Description */}
        {chantier.description && (
          <div style={{ background: 'var(--gray-100)', borderRadius: 8, padding: '12px 16px', marginBottom: 20, fontSize: 13, color: 'var(--gray-700)', lineHeight: 1.5 }}>
            {chantier.description}
          </div>
        )}

        {/* Tabs */}
        <div style={{ display: 'flex', borderBottom: '2px solid var(--gray-200)', marginBottom: 20 }}>
          {tabs.map(([key, label]) => (
            <button key={key} onClick={() => setTab(key)} style={{ padding: '10px 20px', background: 'none', border: 'none', borderBottom: tab === key ? '2px solid var(--blue)' : '2px solid transparent', marginBottom: -2, color: tab === key ? 'var(--blue)' : 'var(--gray-500)', fontWeight: tab === key ? 600 : 400, fontSize: 14, transition: 'color 150ms', cursor: 'pointer' }}>
              {label}
            </button>
          ))}
        </div>

        {/* ── Tab Zones ── */}
        {tab === 'zones' && (
          <div style={{ display: 'grid', gridTemplateColumns: 'repeat(2,1fr)', gap: 12 }}>
            {zones.map(z => (
              <div key={z.nom} style={{ background: '#fff', border: '1px solid var(--gray-200)', borderRadius: 10, padding: 16 }}>
                <div style={{ display: 'flex', justifyContent: 'space-between', marginBottom: 8 }}>
                  <span style={{ fontWeight: 600, fontSize: 14 }}>{z.nom}</span>
                  <span style={{ fontFamily: "'Barlow Condensed',sans-serif", fontWeight: 700, fontSize: 18 }}>{z.avancement}%</span>
                </div>
                <ProgressBar value={z.avancement} height={8} />
                <div style={{ fontSize: 11, color: 'var(--gray-400)', marginTop: 6 }}>
                  {taches.filter(t => t.zone === z.nom).length} tâche(s) · {taches.filter(t => t.zone === z.nom && t.statut === 'Terminé').length} terminée(s)
                </div>
              </div>
            ))}
          </div>
        )}

        {/* ── Tab Tâches ── */}
        {tab === 'taches' && (
          <div>
            <div style={{ display: 'flex', alignItems: 'center', justifyContent: 'space-between', marginBottom: 12 }}>
              <p style={{ fontSize: 12, color: 'var(--gray-400)' }}>
                Glisse les tâches pour les réordonner · Clique sur la durée pour la modifier
              </p>
              <Btn onClick={() => setShowModal(true)}>+ Nouvelle tâche</Btn>
            </div>

            {tachesParZone.map(zone => zone.taches.length > 0 && (
              <div key={zone.nom} style={{ marginBottom: 24 }}>
                <h3 style={{ fontSize: 12, fontWeight: 600, color: 'var(--gray-500)', textTransform: 'uppercase', letterSpacing: 0.5, marginBottom: 8, display: 'flex', alignItems: 'center', gap: 8 }}>
                  <div style={{ height: 1, background: 'var(--gray-200)', flex: 1 }} />
                  {zone.nom} ({zone.taches.length} tâche{zone.taches.length > 1 ? 's' : ''})
                  <div style={{ height: 1, background: 'var(--gray-200)', flex: 1 }} />
                </h3>

                {/* Calcul des dates en séquence pour cette zone */}
                {(() => {
                  let currentDate = chantier.date_debut;
                  return zone.taches.map((t, i) => {
                    const dateDebut = currentDate;
                    const dateFin = currentDate ? addJoursOuvres(currentDate, (t.duree_jours || 1) - 1) : null;
                    if (dateFin) currentDate = addJoursOuvres(dateFin, 1);
                    const globalIdx = taches.findIndex(tt => tt.id === t.id);
                    return (
                      <TacheLine key={t.id} tache={t} index={globalIdx}
                        dateDebut={dateDebut}
                        onStatut={handleTacheStatut} onDelete={handleDeleteTache} onDuree={handleDuree}
                        onDragStart={handleDragStart} onDragOver={handleDragOver} onDrop={handleDrop} />
                    );
                  });
                })()}
              </div>
            ))}
            {taches.length === 0 && <div style={{ textAlign: 'center', padding: 40, color: 'var(--gray-400)' }}>Aucune tâche. Cliquez sur "+ Nouvelle tâche" pour commencer.</div>}
          </div>
        )}

        {/* ── Tab Planning ── */}
        {tab === 'planning' && (
          <div>
            <div style={{ display: 'flex', alignItems: 'center', gap: 12, marginBottom: 16 }}>
              <div style={{ fontSize: 12, color: 'var(--gray-500)' }}>
                Planning calculé automatiquement depuis la date de début · Les tâches s'enchaînent en jours ouvrés
              </div>
            </div>
            {!chantier.date_debut ? (
              <div style={{ background: 'var(--amber-light)', border: '1px solid #FDE68A', borderRadius: 8, padding: 16, color: '#92400E', fontSize: 13 }}>
                ⚠ Aucune date de début définie pour ce chantier. Modifie le statut pour définir une date.
              </div>
            ) : (
              <VuePlanning taches={taches} dateDebutChantier={chantier.date_debut} />
            )}
          </div>
        )}

        {/* ── Tab Devis ── */}
        {tab === 'devis' && (
          <div style={{ display: 'flex', flexDirection: 'column', gap: 10 }}>
            {(devis || []).map(d => (
              <div key={d.id} style={{ background: '#fff', border: '1px solid var(--gray-200)', borderRadius: 8, padding: '14px 18px', display: 'flex', alignItems: 'center', gap: 16 }}>
                <div style={{ width: 36, height: 36, background: 'var(--blue-light)', borderRadius: 7, display: 'flex', alignItems: 'center', justifyContent: 'center', fontSize: 11, fontWeight: 700, color: '#1D4ED8', flexShrink: 0 }}>
                  {d.entreprise_nom?.slice(0, 2)}
                </div>
                <div style={{ flex: 1 }}>
                  <div style={{ fontWeight: 500, fontSize: 13 }}>{d.entreprise_nom}</div>
                  <div style={{ fontSize: 12, color: 'var(--gray-500)' }}>{d.description}{d.n_devis ? ` · ${d.n_devis}` : ''}</div>
                  <div style={{ fontSize: 11, color: 'var(--gray-400)' }}>Reçu le {fmtDate(d.date_reception)}</div>
                </div>
                <div style={{ textAlign: 'right' }}>
                  <div style={{ fontFamily: "'Barlow Condensed',sans-serif", fontWeight: 700, fontSize: 16 }}>{fmtEuro(d.montant_ttc)}</div>
                  <div style={{ fontSize: 11, color: 'var(--gray-400)' }}>{fmtEuro(d.montant_ht)} HT</div>
                </div>
                <span style={{ fontSize: 10, fontWeight: 600, padding: '3px 8px', borderRadius: 20, background: '#DCFCE7', color: '#15803D', border: '1px solid #BBF7D0' }}>{d.statut}</span>
              </div>
            ))}
            {(!devis || devis.length === 0) && <div style={{ textAlign: 'center', padding: 40, color: 'var(--gray-400)' }}>Aucun devis pour ce chantier.</div>}
          </div>
        )}
      </div>

      {/* ── Modal nouvelle tâche ── */}
      {showModal && (
        <div style={{ position: 'fixed', inset: 0, background: 'rgba(0,0,0,.4)', zIndex: 200, display: 'flex', alignItems: 'center', justifyContent: 'center', padding: 16 }}>
          <div style={{ background: '#fff', borderRadius: 12, padding: 24, width: '100%', maxWidth: 480, maxHeight: '90vh', overflowY: 'auto' }}>
            <h2 style={{ fontSize: 20, marginBottom: 20 }}>Nouvelle tâche</h2>
            <form onSubmit={handleAddTache}>
              <div style={{ marginBottom: 12 }}>
                <label style={labelStyle}>Zone *</label>
                <select style={selectStyle} value={form.zone} onChange={e => setForm(f => ({ ...f, zone: e.target.value }))} required>
                  <option value="">— Sélectionner —</option>
                  {zones.map(z => <option key={z.nom}>{z.nom}</option>)}
                </select>
              </div>
              <div style={{ display: 'grid', gridTemplateColumns: '1fr 1fr', gap: 12, marginBottom: 12 }}>
                <div>
                  <label style={labelStyle}>Type *</label>
                  <select style={selectStyle} value={form.type_tache} onChange={e => setForm(f => ({ ...f, type_tache: e.target.value }))}>
                    {['Dépose', 'Pose', 'Finition', 'Contrôle'].map(t => <option key={t}>{t}</option>)}
                  </select>
                </div>
                <div>
                  <label style={labelStyle}>Durée (jours ouvrés) *</label>
                  <input type="number" min="1" max="365" style={inputStyle} value={form.duree_jours} onChange={e => setForm(f => ({ ...f, duree_jours: Number(e.target.value) }))} required />
                </div>
              </div>
              <div style={{ marginBottom: 12 }}>
                <label style={labelStyle}>Entreprise intervenante</label>
                <select style={selectStyle} value={form.entreprise_id} onChange={e => {
                  const ent = ENTREPRISES_SEED.find(en => en.id === e.target.value);
                  setForm(f => ({ ...f, entreprise_id: e.target.value, entreprise_nom: ent?.nom || '' }));
                }}>
                  <option value="">— Sélectionner —</option>
                  {/* Intervenants du chantier en premier */}
                  {chantier.intervenants?.length > 0 && (
                    <optgroup label="Intervenants du chantier">
                      {ENTREPRISES_SEED.filter(e => chantier.intervenants.includes(e.nom)).map(e => <option key={e.id} value={e.id}>{e.nom}</option>)}
                    </optgroup>
                  )}
                  <optgroup label="Toutes les entreprises">
                    {ENTREPRISES_SEED.filter(e => !chantier.intervenants?.includes(e.nom)).map(e => <option key={e.id} value={e.id}>{e.nom}</option>)}
                  </optgroup>
                </select>
              </div>
              <div style={{ marginBottom: 12 }}>
                <label style={labelStyle}>Description *</label>
                <textarea style={{ ...inputStyle, minHeight: 72, resize: 'vertical' }} value={form.description} onChange={e => setForm(f => ({ ...f, description: e.target.value }))} required placeholder="Ex : Pose sol souple côté gauche" />
              </div>
              <div style={{ marginBottom: 20 }}>
                <label style={labelStyle}>Date d'échéance</label>
                <input type="date" style={inputStyle} value={form.date_echeance} onChange={e => setForm(f => ({ ...f, date_echeance: e.target.value }))} />
              </div>
              <div style={{ display: 'flex', gap: 8, justifyContent: 'flex-end' }}>
                <Btn variant="secondary" onClick={() => setShowModal(false)} type="button">Annuler</Btn>
                <Btn type="submit" disabled={saving}>{saving ? 'Ajout...' : 'Ajouter la tâche'}</Btn>
              </div>
            </form>
          </div>
        </div>
      )}
    </Layout>
  );
}
